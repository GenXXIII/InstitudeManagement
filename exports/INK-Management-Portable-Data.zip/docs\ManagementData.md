# Portable Management Data

This repository contains the complete institute dataset in `docs/Data.txt`, an exact live export in `exports/ManagementData.json`, and the deterministic database importer in `scripts/import-institute-data.ps1`.

## Dataset

| Resource | Records | Readable IDs |
| --- | ---: | --- |
| Departments | 5 | `DEP-1` to `DEP-5` |
| Teachers | 40 | `TEA-1` to `TEA-40` |
| Students | 800 | `STU-1` to `STU-800` |
| Courses | 40 | `COU-1` to `COU-40` |
| Classrooms | 13 | `101` to `501` |
| Timetable | 180 | `TIM-1` to `TIM-180` |
| Attendance records | 800 | `ATT-1` to `ATT-800` |
| Grade records | 800 | `GRD-1` to `GRD-800` |

The importer creates complete relationship-backed records, not mock frontend rows. It generates emails, profile photos, shifts, department relationships, one teacher per course, current attendance, current grades, the full weekly timetable, and audit history.

Run `scripts/export-management-data.ps1` whenever a new exact JSON snapshot of the live API data is needed. The export includes database IDs for reference, but those IDs must not be inserted into another database. Use the importer so the destination database creates valid internal IDs and relationships.

Attendance and Grades are not shown under Management, but their database records remain available to Operation, Record, Record History, Results, and History.

## New Device Import

Run these commands from the repository root on a new Windows device:

```powershell
Copy-Item .env.example .env
docker compose up -d --build --wait --wait-timeout 180
.\scripts\import-institute-data.ps1
docker compose restart api
```

The host SQL connection is `127.0.0.1,1433`. `INK-SQL-SERVER` is the Docker container and network name. The database is `INK_Manangement`, the SQL user is `sa`, and the configured password is `1234`.

The importer replaces data in Management, timetable, attendance, grades, class-session records, and audit history. Use it for a fresh database or only when replacing the existing dataset is intended.

## Verification

```powershell
$resources = @("departments", "teachers", "students", "courses", "classrooms", "timetable")
foreach ($resource in $resources) {
    $rows = Invoke-RestMethod "http://127.0.0.1:5080/api/catalog/$resource"
    Write-Output "$resource $($rows.Count)"
}
```

Expected counts are `5`, `40`, `800`, `40`, `13`, and `180` in the order above.

## Prompt For Another AI

Use this request on the other device:

> Open the InstituteManagement repository. Treat `docs/Data.txt` as the dataset source and `scripts/import-institute-data.ps1` as the import implementation. Start the complete Docker stack, wait until it is healthy, run the importer against `127.0.0.1,1433`, restart the API, and verify every expected count in `docs/ManagementData.md`. Do not create mock frontend data and do not report completion until Docker, API, database counts, Record, and History are verified.
